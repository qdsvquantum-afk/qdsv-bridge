def qrisp_case_compliance_eq_constant(fields, decision, checkpoint):
    with fields["compliance"] == 1:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()
