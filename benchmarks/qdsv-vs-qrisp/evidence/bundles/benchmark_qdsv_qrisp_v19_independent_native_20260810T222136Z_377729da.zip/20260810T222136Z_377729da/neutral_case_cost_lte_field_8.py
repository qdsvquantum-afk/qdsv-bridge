CASE_ID = 'cost_lte_field_8'
CANDIDATE_COUNT = 8
BUSINESS_DATA = {'cost': [550, 590, 610, 500, 580, 450, 600, 599],
 'budget': [600, 600, 600, 600, 600, 600, 600, 600]}
PUBLIC_PREDICATE = {'op': 'lte', 'left': {'op': 'field', 'name': 'cost'}, 'right': {'op': 'field', 'name': 'budget'}}
BUSINESS_CASE = {
    'title': 'Desigualdad campo ancho a campo',
    'business_family': 'comparator_microdiagnostic',
    'candidate_count': CANDIDATE_COUNT,
    'data': BUSINESS_DATA,
    'predicate': PUBLIC_PREDICATE,
    'qdsv_route': 'bounded_predicate',
}
