

def qrisp_bit_width_unsigned(values):
    maximum = max([0, *[int(value) for value in values]])
    return max(1, math.ceil(math.log2(maximum + 1)))

def qrisp_validate_native_case(case_id, case):
    expected_fields = {
        "compliance_eq_constant_8": {"compliance"},
        "compliance_gte_constant_8": {"compliance"},
        "cost_eq_constant_8": {"cost"},
        "cost_lte_constant_8": {"cost"},
        "cost_lte_field_8": {"cost", "budget"},
    }
    if case_id not in expected_fields:
        raise AdapterNotImplemented(f"No existe builder Qrisp nativo para {case_id!r}.")
    if set(case) != {"candidate_count", "data"}:
        raise AdapterError("El builder Qrisp solo acepta candidate_count y data.")
    n = int(case["candidate_count"])
    if n <= 0:
        raise AdapterError("candidate_count debe ser positivo.")
    if set(case["data"]) != expected_fields[case_id]:
        raise AdapterError(
            f"Campos Qrisp inesperados para {case_id}: {sorted(case['data'])}"
        )
    for name, values in case["data"].items():
        if len(values) != n:
            raise AdapterError(f"Longitud incorrecta para {name}: {len(values)} != {n}")
        if not all(isinstance(value, (int, float, bool)) for value in values):
            raise AdapterError(f"Valores no numéricos en {name}")

def qrisp_prepare_index_exact(index, candidate_count):
    from qrisp import h, prepare
    padded_size = 1 << len(index.reg)
    if candidate_count == padded_size:
        h(index)
        return
    probabilities = [
        1 / candidate_count if value < candidate_count else 0.0
        for value in range(padded_size)
    ]
    prepare(index, np.sqrt(probabilities), method="qiskit")

def qrisp_toggle_explicit_field(index, field, values):
    from qrisp import control, x
    for candidate, value in enumerate(values):
        integer = int(value)
        for bit in range(len(field.reg)):
            if (integer >> bit) & 1:
                with control(index.reg, ctrl_state=candidate):
                    x(field[bit])

def qrisp_build_explicit_fields(index, case):
    from qrisp import QuantumFloat
    fields = {}
    loaders = []
    for name, values in case["data"].items():
        field = QuantumFloat(
            qrisp_bit_width_unsigned(values),
            signed=False,
            qs=index.qs,
            name=f"{name}_value",
        )
        qrisp_toggle_explicit_field(index, field, values)
        fields[name] = field
        loaders.append((field, list(values)))
    return fields, loaders

def qrisp_case_compliance_eq_constant(fields, decision, checkpoint):
    with fields["compliance"] == 1:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()

def qrisp_case_compliance_gte_constant(fields, decision, checkpoint):
    with fields["compliance"] >= 1:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()

def qrisp_case_cost_eq_constant(fields, decision, checkpoint):
    with fields["cost"] == 550:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()

def qrisp_case_cost_lte_constant(fields, decision, checkpoint):
    with fields["cost"] <= 600:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()

def qrisp_case_cost_lte_field(fields, decision, checkpoint):
    with fields["cost"] <= fields["budget"]:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()

QRISP_NATIVE_CASE_BUILDERS = {
    "compliance_eq_constant_8": qrisp_case_compliance_eq_constant,
    "compliance_gte_constant_8": qrisp_case_compliance_gte_constant,
    "cost_eq_constant_8": qrisp_case_cost_eq_constant,
    "cost_lte_constant_8": qrisp_case_cost_lte_constant,
    "cost_lte_field_8": qrisp_case_cost_lte_field,
}

def qrisp_apply_native_case(case_id, fields, decision, checkpoint):
    builder = QRISP_NATIVE_CASE_BUILDERS.get(case_id)
    if builder is None:
        raise AdapterNotImplemented(f"No existe builder Qrisp nativo para {case_id!r}.")
    checkpoint(
        "native_condition_environment",
        current_native_event="condition_environment_start",
        native_case_id=case_id,
    )
    builder(fields, decision, checkpoint)
    checkpoint(
        "field_cleanup",
        current_native_event="condition_environment_complete",
        native_condition_completed=True,
    )

def qrisp_clean_explicit_fields(index, loaders):
    for field, values in reversed(loaders):
        qrisp_toggle_explicit_field(index, field, values)
        field.delete(verify=False)

def qrisp_normalize_qubit_identifier(value):
    text = str(value).strip()
    for old, new in [(".", "_"), ("[", "_"), ("]", ""), (" ", "")]:
        text = text.replace(old, new)
    return text

def qrisp_qiskit_register_index_map(circuit):
    aliases = {}
    for qreg in circuit.qregs:
        for offset, bit in enumerate(qreg):
            index = circuit.find_bit(bit).index
            for name in {qreg.name, f"{qreg.name}_{offset}", f"{qreg.name}.{offset}"}:
                aliases.setdefault(qrisp_normalize_qubit_identifier(name), []).append(index)
    return aliases

def qrisp_locate_qubit_indices(compiled, qiskit_circuit, qubits):
    aliases = qrisp_qiskit_register_index_map(qiskit_circuit)
    indices = []
    sources = []
    for qubit in qubits:
        if qubit in compiled.qubits:
            indices.append(compiled.qubits.index(qubit))
            sources.append("compiled_qubit_identity")
            continue
        normalized = qrisp_normalize_qubit_identifier(qubit)
        matches = sorted(set(aliases.get(normalized, [])))
        if len(matches) != 1:
            raise AdapterError(
                f"No se pudo localizar inequívocamente {qubit!s}; matches={matches}"
            )
        indices.append(matches[0])
        sources.append("qiskit_register_fallback")
    source = sources[0] if len(set(sources)) == 1 else "mixed"
    return indices, source

def qrisp_write_phase_progress(progress_path, record):
    if not progress_path:
        return
    import pathlib as _pathlib
    path = _pathlib.Path(progress_path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2, default=repr),
        encoding="utf-8",
    )
    temporary.replace(path)

def build_qrisp_case(case_id, case, progress_path=None):
    qrisp_validate_native_case(case_id, case)
    compatibility_record = activate_qrisp_packaging_compatibility()

    import base64 as _base64
    import io as _io
    from qrisp import QuantumBool, QuantumFloat
    from qiskit import qpy as _qpy

    build_started = time.perf_counter()
    phase_timing = {
        "version": "qrisp_native_phase_timing.v1",
        "current_phase": "candidate_preparation",
        "current_native_event": "not_started",
        "completed": False,
    }

    def checkpoint(phase, **metrics):
        phase_timing.update(metrics)
        phase_timing["current_phase"] = phase
        phase_timing["elapsed_seconds_at_last_checkpoint"] = (
            time.perf_counter() - build_started
        )
        qrisp_write_phase_progress(progress_path, phase_timing)

    checkpoint("candidate_preparation")
    phase_started = time.perf_counter()
    index = QuantumFloat(
        max(1, math.ceil(math.log2(case["candidate_count"]))),
        signed=False,
        name="candidate",
    )
    qrisp_prepare_index_exact(index, case["candidate_count"])
    checkpoint(
        "field_loading",
        candidate_preparation_seconds=time.perf_counter() - phase_started,
    )

    phase_started = time.perf_counter()
    fields, loaders = qrisp_build_explicit_fields(index, case)
    checkpoint(
        "native_condition_environment",
        field_loading_seconds=time.perf_counter() - phase_started,
    )

    phase_started = time.perf_counter()
    decision = QuantumBool(qs=index.qs, name="decision")
    qrisp_apply_native_case(case_id, fields, decision, checkpoint)
    condition_environment_seconds = time.perf_counter() - phase_started

    phase_started = time.perf_counter()
    qrisp_clean_explicit_fields(index, loaders)
    checkpoint(
        "compile",
        condition_environment_seconds=condition_environment_seconds,
        field_cleanup_seconds=time.perf_counter() - phase_started,
    )

    phase_started = time.perf_counter()
    intended = list(index.reg) + list(decision.reg)
    compiled = decision.qs.compile(
        workspace=0,
        intended_measurements=intended,
        disable_uncomputation=False,
        compile_mcm=False,
    )
    checkpoint(
        "qiskit_conversion",
        compile_seconds=time.perf_counter() - phase_started,
    )

    phase_started = time.perf_counter()
    circuit = compiled.to_qiskit()
    checkpoint(
        "qpy_export",
        qiskit_conversion_seconds=time.perf_counter() - phase_started,
    )
    candidate_bits, candidate_mapping_source = qrisp_locate_qubit_indices(
        compiled, circuit, list(index.reg)
    )
    predicate_bits, predicate_mapping_source = qrisp_locate_qubit_indices(
        compiled, circuit, list(decision.reg)
    )
    mapping_hint = {
        "candidate_bits": candidate_bits,
        "predicate_bits": predicate_bits,
        "source": (
            candidate_mapping_source
            if candidate_mapping_source == predicate_mapping_source
            else "mixed"
        ),
    }

    phase_started = time.perf_counter()
    qpy_buffer = _io.BytesIO()
    _qpy.dump(circuit, qpy_buffer)
    qpy_b64 = _base64.b64encode(qpy_buffer.getvalue()).decode("ascii")
    checkpoint(
        "qasm_export",
        qpy_export_seconds=time.perf_counter() - phase_started,
    )

    phase_started = time.perf_counter()
    qasm_source = None
    qasm_export_status = "not_attempted"
    qasm_export_error = None
    try:
        qasm_source = qasm2.dumps(circuit)
        qasm_export_status = "exported"
    except Exception as exc:
        qasm_export_status = "optional_export_failed"
        qasm_export_error = f"{type(exc).__name__}: {exc}"

    checkpoint(
        "completed",
        qasm_export_seconds=time.perf_counter() - phase_started,
        total_build_seconds=time.perf_counter() - build_started,
        current_native_event="completed",
        completed=True,
    )

    return circuit, qasm_source, qpy_b64, {
        "qasm_export_status": qasm_export_status,
        "qasm_export_error": qasm_export_error,
        "mapping_hint": mapping_hint,
        "compatibility_record": compatibility_record,
        "strategy": "native_condition_environment",
        "native_route": case_id,
        "candidate_preparation": "exact_valid_domain",
        "workspace": 0,
        "disable_uncomputation": False,
        "intended_measurements": True,
        "observable_output": "decision",
        "phase_timing": phase_timing,
    }


