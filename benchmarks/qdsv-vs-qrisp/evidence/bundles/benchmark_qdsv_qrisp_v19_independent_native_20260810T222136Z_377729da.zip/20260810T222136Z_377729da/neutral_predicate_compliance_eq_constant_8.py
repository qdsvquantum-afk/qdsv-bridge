PUBLIC_PREDICATE = {'op': 'eq', 'left': {'op': 'field', 'name': 'compliance'}, 'right': {'op': 'const', 'value': 1}}
