def qrisp_case_cost_eq_constant(fields, decision, checkpoint):
    with fields["cost"] == 550:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()
