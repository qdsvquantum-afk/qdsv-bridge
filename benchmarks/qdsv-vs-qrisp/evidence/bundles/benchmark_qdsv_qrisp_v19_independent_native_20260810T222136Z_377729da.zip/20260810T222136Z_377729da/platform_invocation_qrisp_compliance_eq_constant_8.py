QRISP_INPUT = {"candidate_count": CANDIDATE_COUNT, "data": BUSINESS_DATA}
circuit, qasm_source, qpy_b64, metadata = build_qrisp_case(CASE_ID, QRISP_INPUT)
