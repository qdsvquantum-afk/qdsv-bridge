PUBLIC_PREDICATE = {'op': 'eq', 'left': {'op': 'field', 'name': 'cost'}, 'right': {'op': 'const', 'value': 550}}
