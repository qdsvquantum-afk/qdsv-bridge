PUBLIC_PREDICATE = {'op': 'lte', 'left': {'op': 'field', 'name': 'cost'}, 'right': {'op': 'const', 'value': 600}}
