CASE_ID = 'cost_lte_constant_8'
CANDIDATE_COUNT = 8
BUSINESS_DATA = {'cost': [550, 590, 610, 500, 580, 450, 600, 599]}
PUBLIC_PREDICATE = {'op': 'lte', 'left': {'op': 'field', 'name': 'cost'}, 'right': {'op': 'const', 'value': 600}}
BUSINESS_CASE = {
    'title': 'Desigualdad campo ancho a constante',
    'business_family': 'comparator_microdiagnostic',
    'candidate_count': CANDIDATE_COUNT,
    'data': BUSINESS_DATA,
    'predicate': PUBLIC_PREDICATE,
    'qdsv_route': 'bounded_predicate',
}
