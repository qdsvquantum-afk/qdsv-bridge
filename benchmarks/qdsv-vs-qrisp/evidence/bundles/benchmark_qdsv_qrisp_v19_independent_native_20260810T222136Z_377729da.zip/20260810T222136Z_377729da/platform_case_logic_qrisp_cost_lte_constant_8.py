def qrisp_case_cost_lte_constant(fields, decision, checkpoint):
    with fields["cost"] <= 600:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()
