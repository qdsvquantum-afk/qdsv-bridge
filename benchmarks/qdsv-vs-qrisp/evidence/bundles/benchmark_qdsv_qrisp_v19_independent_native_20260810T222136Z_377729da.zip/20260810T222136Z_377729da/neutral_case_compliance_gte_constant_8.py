CASE_ID = 'compliance_gte_constant_8'
CANDIDATE_COUNT = 8
BUSINESS_DATA = {'compliance': [1, 1, 1, 0, 1, 1, 1, 1]}
PUBLIC_PREDICATE = {'op': 'gte', 'left': {'op': 'field', 'name': 'compliance'}, 'right': {'op': 'const', 'value': 1}}
BUSINESS_CASE = {
    'title': 'Desigualdad campo binario a constante',
    'business_family': 'comparator_microdiagnostic',
    'candidate_count': CANDIDATE_COUNT,
    'data': BUSINESS_DATA,
    'predicate': PUBLIC_PREDICATE,
    'qdsv_route': 'bounded_predicate',
}
