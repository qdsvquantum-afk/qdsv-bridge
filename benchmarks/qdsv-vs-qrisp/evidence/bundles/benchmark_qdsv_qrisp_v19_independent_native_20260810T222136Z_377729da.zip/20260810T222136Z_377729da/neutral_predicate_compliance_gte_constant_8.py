PUBLIC_PREDICATE = {'op': 'gte', 'left': {'op': 'field', 'name': 'compliance'}, 'right': {'op': 'const', 'value': 1}}
