def qrisp_case_cost_lte_field(fields, decision, checkpoint):
    with fields["cost"] <= fields["budget"]:
        checkpoint("native_condition_environment", current_native_event="condition_entered")
        decision.flip()
