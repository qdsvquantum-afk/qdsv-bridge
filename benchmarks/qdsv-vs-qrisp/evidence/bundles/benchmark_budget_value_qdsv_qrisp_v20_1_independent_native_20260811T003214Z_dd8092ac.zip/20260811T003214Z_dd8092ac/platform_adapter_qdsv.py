
from qdsv_bridge import build_predicate_spec

QDSV_FORBIDDEN_SPEC_KEYS = {
    "expected", "expected_true_indices", "expected_decision", "true_indices",
    "ground_truth", "label", "labels", "answer", "answers", "solution",
    "winner", "winning_candidates", "mark_bit", "precomputed_result",
}


def qdsv_forbidden_spec_paths(value, path="root"):
    findings = []
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in QDSV_FORBIDDEN_SPEC_KEYS:
                findings.append(f"{path}.{key}")
            findings.extend(qdsv_forbidden_spec_paths(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            findings.extend(qdsv_forbidden_spec_paths(child, f"{path}[{index}]"))
    return findings

QDSV_NUMERIC_OPS = {"field", "const", "add", "sub", "mul", "squared_diff"}
QDSV_DECISIONS = {"eq", "ne", "lt", "lte", "gt", "gte"}


def ast_ops(node):
    result = {node["op"]}
    for key in ("left", "right", "arg"):
        if isinstance(node.get(key), dict):
            result |= ast_ops(node[key])
    for child in node.get("args", []):
        result |= ast_ops(child)
    return result


def qdsv_numeric_expr(node):
    op = node["op"]
    if op == "field":
        return {
            "op": "field",
            "dataset": "input_0",
            "row": {"var": "x"},
            "column": node["name"],
        }
    if op == "const":
        return node["value"]
    if op == "add":
        terms = [qdsv_numeric_expr(x) for x in node["args"]]
        if not terms:
            raise AdapterError("La suma publica requiere al menos un termino.")
        result = terms[0]
        for term in terms[1:]:
            result = {"op": "add", "args": [result, term]}
        return result
    if op in {"sub", "mul", "squared_diff"}:
        return {
            "op": op,
            "left": qdsv_numeric_expr(node["left"]),
            "right": qdsv_numeric_expr(node["right"]),
        }
    raise AdapterNotImplemented(f"Operacion QDSV no implementada en el adaptador: {op}")


def qdsv_spec_from_case(case):
    validate_public_case(case)
    predicate = case["predicate"]
    rows = [
        {
            "candidate_index": index,
            **{name: values[index] for name, values in case["data"].items()},
        }
        for index in range(case["candidate_count"])
    ]

    route = case.get("qdsv_route")
    if route == "bounded_predicate":
        spec = build_predicate_spec(
            rows=rows,
            predicate=predicate,
            shots=SHOTS,
            artifact_format="qasm2",
            backend_family="qiskit",
            materialization_mode="superposition_oracle",
            max_qubits=256,
            max_depth=1_000_000,
            logical_optimization=dict(LOGICAL_OPTIMIZATION_CONTRACT),
        )
        if qdsv_forbidden_spec_paths(spec):
            raise AdapterError(f"El spec contiene claves prohibidas: {qdsv_forbidden_spec_paths(spec)}")
        return spec
    if route != "score_expression":
        raise AdapterNotImplemented(f"Ruta QDSV publica no implementada: {route!r}")

    if predicate["op"] not in QDSV_DECISIONS:
        raise AdapterNotImplemented("La raiz del predicado no es una comparacion.")
    if predicate["right"].get("op") != "const":
        raise AdapterNotImplemented("El adaptador QDSV requiere un umbral constante.")
    numeric_ops = ast_ops(predicate["left"])
    if not numeric_ops <= QDSV_NUMERIC_OPS:
        raise AdapterNotImplemented(
            f"Operaciones numericas no implementadas: {sorted(numeric_ops-QDSV_NUMERIC_OPS)}"
        )

    term = {
        "name": "benchmark_public_expression",
        "value": qdsv_numeric_expr(predicate["left"]),
        "importance": 1,
        "priority": 1,
        "adjustments": [],
    }
    problem_spec = {
        "target": "quantum_hardware",
        "domain": {
            "variable": "x",
            "type": "int_range",
            "start": 0,
            "end": case["candidate_count"] - 1,
        },
        "data_binding": {
            "kind": "data_binding.v1",
            "datasets": [{
                "id": "input_0",
                "row_variable": "x",
                "index_field": "candidate_index",
                "rows": rows,
            }],
        },
        "model": {
            "kind": "score_model",
            "version": "2.0",
            "numeric_contract": {
                "output_scale": 8192,
                "max_function_states": 16384,
                "max_input_qubits": 20,
            },
            "score": {
                "terms": [term],
                "penalty": 0,
                "epsilon": 0.001,
                "decision": predicate["op"],
                "threshold": predicate["right"]["value"],
                "execution_strategy": "semantic_auto",
            },
        },
        "query": {"kind": "find_any"},
        "evidence": {"shots": SHOTS},
    }
    spec = {
        "problem_spec": problem_spec,
        "target": {
            "format": "qasm2",
            "backend_family": "qiskit",
            "logical_optimization": dict(LOGICAL_OPTIMIZATION_CONTRACT),
        },
        "limits": {"max_qubits": 256, "max_depth": 1_000_000},
        "materialization_policy": {
            "mode": "superposition_oracle",
            "shots": SHOTS,
        },
    }
    if qdsv_forbidden_spec_paths(spec):
        raise AdapterError(f"El spec contiene claves prohibidas: {qdsv_forbidden_spec_paths(spec)}")
    return spec


def classify_qdsv_exception(exc):
    payload = getattr(exc, "payload", None)
    text = (
        json.dumps(payload, default=repr)
        if payload is not None
        else str(exc)
    ).lower()
    if "quota" in text or "sdk_quota_exceeded" in text or "http 429" in text:
        return "quota_exhausted"
    if "resource" in text or "size_limit" in text or "max_qubit" in text or "max_depth" in text:
        return "resource_rejected"
    if "unsupported" in text or "missing_capabil" in text:
        return "unsupported"
    if "invalid" in text or "validation" in text:
        return "invalid_spec"
    if "timeout" in text:
        return "construction_timeout"
    if "connection" in text or "network" in text or "service" in text or "transport" in text:
        return "service_error"
    return "framework_construction_error"
