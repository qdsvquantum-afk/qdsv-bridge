# Budget value QDSV Bridge vs Qrisp nativo independiente v20.1

- Run ID: `20260811T003214Z_dd8092ac`
- Perfil principal: `budget_value_qdsv_qrisp_v20_1_independent_native`
- Politica de versiones: `frozen_v20_1_budget_value_independent_native_bilateral`
- Perfil onboarding: `readme_quickstart`
- Python: `3.12.13`

## Alcance

La comparación termina en el artefacto lógico ideal, QASM/Qiskit, evidencia y replay independiente.
Construcción, replay y normalización tienen timeout y memoria separados.
Esta corrida congela Bridge 0.6.1 y separa artefactos canonicos, optimizados nativos y normalizacion externa.
El peak RSS es un guardrail absoluto del arbol de procesos e incluye paginas heredadas; no se usa para comparar plataformas.

## Complejidad del caso

El caso congela dos comparaciones campo-a-campo y una conjuncion antes de construir los circuitos.

|                |   predicate_node_count |   comparison_count |   max_boolean_depth |   candidate_count |   data_field_count | diagnostic_dimension                    | unused_data_fields   |
|:---------------|-----------------------:|-------------------:|--------------------:|------------------:|-------------------:|:----------------------------------------|:---------------------|
| budget_value_8 |                      7 |                  2 |                   1 |                 8 |                  4 | nested_native_and_two_field_comparisons | []                   |

## Preflight operacional

Los canarios solo controlan viabilidad operativa; no usan labels, respuestas esperadas ni resultados semanticos.

``{"QDSV": {"canonical": {"version": "qdsv_canonical_service_preflight.v2", "ok": true, "blocking": false, "status": "passed", "catalog_consulted": true, "canonical_capability_signal": null, "errors": []}, "optimization_optional": {"version": "qdsv_optional_optimization_preflight.v1", "ok": true, "status": "passed", "required_profile": "qiskit_structural_exact_v1", "required_acceptance_policy": "pareto_no_regression_v1", "errors": []}}, "Qrisp": {"version": "qrisp_adapter_qualification_reference.v1", "status": "not_required", "strategy": "native_condition_environment", "qualification": "official_public_api_pattern", "battery_policy": "execute_each_case_independently"}}``

## Tiempos por fase Qrisp

Los checkpoints sobreviven a timeout o terminación del worker.

| platform   | case_id        | status             |   construction_seconds | qrisp_current_phase   | qrisp_current_native_event   |   qrisp_elapsed_seconds_at_last_checkpoint |   qrisp_candidate_preparation_seconds |   qrisp_field_loading_seconds |   qrisp_condition_environment_seconds |   qrisp_field_cleanup_seconds |   qrisp_compile_seconds |   qrisp_qiskit_conversion_seconds |   qrisp_qpy_export_seconds |   qrisp_qasm_export_seconds |   qrisp_total_build_seconds |
|:-----------|:---------------|:-------------------|-----------------------:|:----------------------|:-----------------------------|-------------------------------------------:|--------------------------------------:|------------------------------:|--------------------------------------:|------------------------------:|------------------------:|----------------------------------:|---------------------------:|----------------------------:|----------------------------:|
| Qrisp      | budget_value_8 | sampled_consistent |                13.4846 | completed             | completed                    |                                    13.4781 |                            0.00155422 |                        0.1534 |                               8.20319 |                      0.683224 |                 3.08252 |                          0.984086 |                   0.100281 |                    0.265914 |                     13.4781 |

## Implementación Qrisp nativa

El caso Qrisp usa dos ConditionEnvironment públicos anidados, sin AST QDSV ni expansión ANF.

``{"version": "qrisp_native_case_manifest.v2", "framework": "qrisp", "framework_version": "0.9.6", "strategy": "native_nested_condition_environment", "uses_qdsv_code": false, "uses_generic_ast_translation": false, "uses_anf_expansion": false, "uses_additional_auto_uncompute_wrapper": false, "compile_disable_uncomputation": false, "official_documentation": ["https://qrisp.eu/reference/Quantum%20Types/QuantumFloat.html", "https://qrisp.eu/reference/Quantum%20Types/QuantumBool.html", "https://qrisp.eu/reference/Quantum%20Environments/ConditionEnvironment.html"], "cases": {"budget_value_8": ["with fields['cost'] <= fields['budget']", "with fields['benefit'] >= fields['min_benefit']"]}, "boolean_composition": "nested_condition_environments_and"}``

## Política de timeout

El límite Qrisp de 1.200 s se aplica al caso y es un guardrail; no se interpreta como velocidad pura del framework.

`construction_seconds` es latencia end-to-end observada, no velocidad pura de compilador.

``{"version": "benchmark_timeout_policy.v2", "qrisp_construction_seconds": 1200, "historical_qrisp_reference_seconds": 900, "cross_track_timeout_comparison_allowed": false, "reason": "budget_value_independent_native_revalidation_v20_1", "interpretation": "independent_builder_guardrail_only_not_compiler_speed"}``

## Controles de entorno

Qrisp: ``{"version": "qrisp_packaging_compatibility.v1", "distribution": "qrisp", "distribution_version": "0.9.6", "canonical_module": "qrisp.permeability.unqomp", "packaged_module": "qrisp.permeability.qc_transformations.unqomp", "alias_applied": true, "module_path": "/usr/local/lib/python3.12/dist-packages/qrisp/permeability/qc_transformations/unqomp.py", "module_sha256": "575a05c250caec4d13b939558c941a8b27026f9bd357d0411f7f30f23f74fa08", "framework_source_modified": false, "semantic_adapter_modified": false}``

Estrategia Qrisp: `native_nested_condition_environment`; preparación exacta del dominio; workspace 0; uncomputation habilitada.

Contrato de independencia: ``{"version": "platform_independence_contract.v2", "claim": "independent_platform_specific_implementations_using_public_interfaces", "no_adapters_claim": false, "local_platform_glue_present": true, "qdsv_builder": "local_spec_layer_then_qdsv_bridge.build_predicate_spec", "qrisp_builder": "manual_nested_native_condition_environment_for_budget_value", "qrisp_track": "Qrisp 0.9.6 native public API + audited packaging compatibility shim", "cross_platform_imports": false, "cross_platform_artifact_reuse": false, "shared_inputs": ["public_business_data", "public_predicate_meaning"], "shared_postconstruction_harness": ["frozen_ground_truth", "mps_replay", "metrics", "normalization"], "ground_truth_visible_during_construction": false}``

## Smoke test del README de Bridge

| access_profile    | excluded_from_cross_platform_benchmark   | status   |
|:------------------|:-----------------------------------------|:---------|
| readme_quickstart | True                                     | not_run  |

El smoke test se excluye de cobertura y recursos cruzados.

## Vistas logicas nativas de QDSV

| run_id                    | platform   | case_id        | artifact_role              | recommended   | delivery_mode   | artifact_status   | artifact_digest                                                         | semantic_equivalence   | artifact_format   |   artifact_bytes | artifact_sha256                                                  | status             | stage   | detected_format   |   replay_seconds |   native_qubits |   native_depth |   native_size | native_ops                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | replay_status     | semantic_status    | sampled_consistency   | verification_strength   |   shots |   observed_mismatch_rate |   observed_invalid_rate |   observed_dirty_rate |   mismatch_probability |   invalid_probability |   dirty_ancilla_probability |   mismatch_zero_event_upper_95_pointwise |   invalid_zero_event_upper_95_pointwise |   dirty_zero_event_upper_95_pointwise |   mismatch_zero_event_upper_95_familywise |   invalid_zero_event_upper_95_familywise |   dirty_zero_event_upper_95_familywise | candidate_distribution_status   |   candidate_distribution_alpha |   candidate_distribution_tolerance |   candidate_marginal_max_error | candidate_bits   | predicate_bits   | mapping_source    | mapping_sources                                                                                                                                                                                                                                                                                                                        | observed_distribution                                                                                                                                                                                            |   peak_rss_mb |   stage_seconds |
|:--------------------------|:-----------|:---------------|:---------------------------|:--------------|:----------------|:------------------|:------------------------------------------------------------------------|:-----------------------|:------------------|-----------------:|:-----------------------------------------------------------------|:-------------------|:--------|:------------------|-----------------:|----------------:|---------------:|--------------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------------------|:-------------------|:----------------------|:------------------------|--------:|-------------------------:|------------------------:|----------------------:|-----------------------:|----------------------:|----------------------------:|-----------------------------------------:|----------------------------------------:|--------------------------------------:|------------------------------------------:|-----------------------------------------:|---------------------------------------:|:--------------------------------|-------------------------------:|-----------------------------------:|-------------------------------:|:-----------------|:-----------------|:------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------:|----------------:|
| 20260811T003214Z_dd8092ac | QDSV       | budget_value_8 | canonical_ideal_artifact   | False         | inline          |                   | sha256:aa6410085db3dc39085ac598a7161c1af3e316bc7af643f63a4abaa8bb4b1297 |                        | qasm2             |            48076 | 6426b070f722903f014aa568075dafd789160473eea24fc47b36ff6c09ba94ce | sampled_consistent | replay  | qasm2             |          1.12047 |              11 |            542 |           794 | {'x': 556, 'mcx': 192, 'measure': 4, 'h': 3, 'ccx': 2, 'mcx_125080201195552': 1, 'mcx_125080201194016': 1, 'mcx_125080201193488': 1, 'mcx_125080201194160': 1, 'mcx_125080201192000': 1, 'mcx_125080201191952': 1, 'mcx_125080201191904': 1, 'mcx_125080201191856': 1, 'mcx_125080201191808': 1, 'mcx_125080201190560': 1, 'mcx_125080201190512': 1, 'mcx_125080201190464': 1, 'mcx_125080201190416': 1, 'mcx_125080201190320': 1, 'mcx_125080201189072': 1, 'mcx_125080201189024': 1, 'mcx_125080201188976': 1, 'mcx_125080201188928': 1, 'cx': 1, 'mcx_125080201187680': 1, 'mcx_125080201187632': 1, 'mcx_125080201187584': 1, 'mcx_125080201187536': 1, 'mcx_125080201186240': 1, 'mcx_125080201186192': 1, 'mcx_125080201186144': 1, 'mcx_125080201186096': 1, 'mcx_125080201186048': 1, 'mcx_125080201184800': 1, 'mcx_125080201184752': 1, 'mcx_125080201184704': 1, 'mcx_125080201184656': 1, 'mcx_125080201184560': 1, 'mcx_125080201092064': 1, 'mcx_125080201090144': 1, 'mcx_125080201088224': 1, 'mcx_125080201086304': 1} | completed_sampled | sampled_consistent | True                  | sampled_mps             |    8192 |                        0 |                       0 |                     0 |                      0 |                     0 |                           0 |                              0.000365623 |                             0.000365623 |                           0.000365623 |                               0.000499673 |                              0.000499673 |                            0.000499673 | statistically_consistent        |                           0.01 |                          0.0212203 |                     0.00756836 | [0, 1, 2]        | [10]             | artifact_contract | ['measurement_contract:root.materialization_evidence.circuit_realization_package.contracts.measurement', 'measurement_contract:root.circuit_realization_package.contracts.measurement', 'measurement_contract:root.semantic_preservation_report.canonical_materialization_evidence.circuit_realization_package.contracts.measurement'] | {'(0, 0)': 0.1212158203125, '(1, 1)': 0.12744140625, '(2, 0)': 0.122314453125, '(3, 0)': 0.118896484375, '(4, 0)': 0.13037109375, '(5, 0)': 0.132568359375, '(6, 0)': 0.1248779296875, '(7, 0)': 0.122314453125} |       364.141 |         1.21573 |
| 20260811T003214Z_dd8092ac | QDSV       | budget_value_8 | optimized_logical_artifact | True          | inline          | accepted          | sha256:ff297d4425641744a78013736e99f09fcdd60688e7db34e6f8d893a6d69648e8 |                        | qasm2             |            43084 | 95b6e4cd172aaf28720729c8c0ee95c19e0d8e923d491ec0fbd3fdec1eb46f5f | sampled_consistent | replay  | qasm2             |          1.0106  |              11 |            368 |           494 | {'x': 256, 'mcx': 192, 'measure': 4, 'h': 3, 'ccx': 2, 'mcx_125080201195552': 1, 'mcx_125080201194016': 1, 'mcx_125080201193488': 1, 'mcx_125080201194160': 1, 'mcx_125080201192000': 1, 'mcx_125080201191952': 1, 'mcx_125080201191904': 1, 'mcx_125080201191856': 1, 'mcx_125080201191808': 1, 'mcx_125080201190560': 1, 'mcx_125080201190512': 1, 'mcx_125080201190464': 1, 'mcx_125080201190416': 1, 'mcx_125080201190320': 1, 'mcx_125080201189072': 1, 'mcx_125080201189024': 1, 'mcx_125080201188976': 1, 'mcx_125080201188928': 1, 'mcx_125080201187680': 1, 'mcx_125080201187632': 1, 'mcx_125080201187584': 1, 'mcx_125080201187536': 1, 'mcx_125080201186240': 1, 'mcx_125080201186192': 1, 'mcx_125080201186144': 1, 'mcx_125080201186096': 1, 'mcx_125080201186048': 1, 'cx': 1, 'mcx_125080201184800': 1, 'mcx_125080201184752': 1, 'mcx_125080201184704': 1, 'mcx_125080201184656': 1, 'mcx_125080201184560': 1, 'mcx_125080201092064': 1, 'mcx_125080201090144': 1, 'mcx_125080201088224': 1, 'mcx_125080201086304': 1} | completed_sampled | sampled_consistent | True                  | sampled_mps             |    8192 |                        0 |                       0 |                     0 |                      0 |                     0 |                           0 |                              0.000365623 |                             0.000365623 |                           0.000365623 |                               0.000499673 |                              0.000499673 |                            0.000499673 | statistically_consistent        |                           0.01 |                          0.0212203 |                     0.00756836 | [0, 1, 2]        | [10]             | artifact_contract | ['measurement_contract:root.materialization_evidence.circuit_realization_package.contracts.measurement', 'measurement_contract:root.circuit_realization_package.contracts.measurement', 'measurement_contract:root.semantic_preservation_report.canonical_materialization_evidence.circuit_realization_package.contracts.measurement'] | {'(0, 0)': 0.1212158203125, '(1, 1)': 0.12744140625, '(2, 0)': 0.122314453125, '(3, 0)': 0.118896484375, '(4, 0)': 0.13037109375, '(5, 0)': 0.132568359375, '(6, 0)': 0.1248779296875, '(7, 0)': 0.122314453125} |       363.48  |         1.21697 |

## Auditoria de optimizacion QDSV

| case_id        | logical_optimization_status   | optimization_contract_status   | optimization_contract_errors   | optimizer_qiskit_version   | canonical_semantic_status   | optimized_semantic_status   | recommended_semantic_status   | native_artifact_role     | recommended_delivery_mode   |
|:---------------|:------------------------------|:-------------------------------|:-------------------------------|:---------------------------|:----------------------------|:----------------------------|:------------------------------|:-------------------------|:----------------------------|
| budget_value_8 | accepted                      | passed                         | []                             | 2.3.0                      | sampled_consistent          | sampled_consistent          | sampled_consistent            | canonical_ideal_artifact | inline                      |

## Cobertura por estado

| platform   |   sampled_consistent |
|:-----------|---------------------:|
| QDSV       |                    1 |
| Qrisp      |                    1 |

## Interpretación de cobertura

| platform   |   total_cases |   passed |   platform_outcomes_observed |   adapter_gaps |   operational_incomplete |   semantic_failures |
|:-----------|--------------:|---------:|-----------------------------:|---------------:|-------------------------:|--------------------:|
| QDSV       |             1 |        1 |                            1 |              0 |                        0 |                   0 |
| Qrisp      |             1 |        1 |                            1 |              0 |                        0 |                   0 |

## Matriz por caso

| case_id        | QDSV               | Qrisp              |
|:---------------|:-------------------|:-------------------|
| budget_value_8 | sampled_consistent | sampled_consistent |

## Fuerza de validación semántica

| case_id        | QDSV        | Qrisp       |
|:---------------|:------------|:------------|
| budget_value_8 | sampled_mps | sampled_mps |

## Comparación directa del caso budget_value_8

| platform   | case_id        | input_artifact_role      | validation         | common_case_eligible   | verification_strength   |   shots |   native_qubits |   native_depth |   native_gates | normalized_status   |   normalized_qubits |   normalized_depth |   normalized_cx |   construction_seconds | operational_status   | resource_comparison_eligible   |
|:-----------|:---------------|:-------------------------|:-------------------|:-----------------------|:------------------------|--------:|----------------:|---------------:|---------------:|:--------------------|--------------------:|-------------------:|----------------:|-----------------------:|:---------------------|:-------------------------------|
| QDSV       | budget_value_8 | canonical_ideal_artifact | sampled_consistent | True                   | sampled_mps             |    8192 |              11 |            542 |            794 | normalized          |                  11 |               7518 |            3997 |                6.19246 | sampled_consistent   | True                           |
| Qrisp      | budget_value_8 | platform_native_artifact | sampled_consistent | True                   | sampled_mps             |    8192 |              47 |           4784 |           9145 | normalized          |                  47 |              26322 |           16858 |               13.4846  | sampled_consistent   | True                           |

Elegibilidad cuantitativa por caso: {'budget_value_8': True}

Caso bilateral habilitado: True

## Casos comparables

Al menos dos plataformas: ['budget_value_8']

Ambas plataformas: ['budget_value_8']

## Esfuerzo verificable

Harness común no atribuible: 40 LOC

Política LOC: ``{"version": "loc_attribution_policy.v2", "common_harness": "reported_once_not_attributed_to_platform", "business_data": "shared_problem_input", "neutral_predicate_specification": "shared_semantic_meaning_executable_input_for_qdsv", "shared_platform_infrastructure": "reusable_across_current_cases", "case_specific_platform_logic": "new_platform_code_required_for_this_business_rule", "end_user_invocation": "visible_submission_surface", "single_combined_winner_metric": false}``

Resumen por plataforma:

| platform   |   shared_platform_infrastructure_loc |   environment_compatibility_loc |   measured_cases |   business_data_loc_median |   neutral_predicate_specification_loc_median |   case_specific_platform_logic_loc_median |   end_user_invocation_loc_median |   platform_specific_new_case_loc_median |
|:-----------|-------------------------------------:|--------------------------------:|-----------------:|---------------------------:|---------------------------------------------:|------------------------------------------:|---------------------------------:|----------------------------------------:|
| QDSV       |                                  170 |                               0 |                1 |                          6 |                                            7 |                                         0 |                                6 |                                       6 |
| Qrisp      |                                  239 |                              38 |                1 |                          6 |                                            7 |                                        13 |                                2 |                                      15 |

Atribución por caso:

| platform   | case_id        | effort_status   |   common_harness_loc |   business_data_loc |   neutral_predicate_specification_loc | neutral_predicate_consumption                     |   shared_platform_infrastructure_loc |   case_specific_platform_logic_loc |   environment_compatibility_loc |   end_user_invocation_loc |   platform_specific_new_case_loc |
|:-----------|:---------------|:----------------|---------------------:|--------------------:|--------------------------------------:|:--------------------------------------------------|-------------------------------------:|-----------------------------------:|--------------------------------:|--------------------------:|---------------------------------:|
| QDSV       | budget_value_8 | measured        |                   40 |                   6 |                                     7 | structured_public_spec_consumed_by_reusable_layer |                                  170 |                                  0 |                               0 |                         6 |                                6 |
| Qrisp      | budget_value_8 | measured        |                   40 |                   6 |                                     7 | manually_reexpressed_in_native_case_logic         |                                  239 |                                 13 |                              38 |                         2 |                               15 |

## Regla de interpretación

No se declara ganador global.
Los recursos solo se comparan si ambas plataformas son sampled_consistent y la normalización común termina.
Las brechas del adaptador, autenticación, soporte, recursos, memoria y corrección permanecen separadas.