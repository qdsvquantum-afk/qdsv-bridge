CASE_ID = 'budget_value_8'
CANDIDATE_COUNT = 8
BUSINESS_DATA = {'cost': [400, 550, 700, 300, 900, 650, 500, 800],
 'budget': [600, 600, 600, 600, 600, 600, 600, 600],
 'benefit': [650, 800, 900, 500, 950, 720, 680, 850],
 'min_benefit': [700, 700, 700, 700, 700, 700, 700, 700]}
PUBLIC_PREDICATE = {'op': 'and',
 'args': [{'op': 'lte',
           'left': {'op': 'field', 'name': 'cost'},
           'right': {'op': 'field', 'name': 'budget'}},
          {'op': 'gte',
           'left': {'op': 'field', 'name': 'benefit'},
           'right': {'op': 'field', 'name': 'min_benefit'}}]}
BUSINESS_CASE = {
    'title': 'Selección bajo presupuesto y beneficio mínimo',
    'business_family': 'bounded_constraints',
    'candidate_count': CANDIDATE_COUNT,
    'data': BUSINESS_DATA,
    'predicate': PUBLIC_PREDICATE,
    'qdsv_route': 'bounded_predicate',
}
