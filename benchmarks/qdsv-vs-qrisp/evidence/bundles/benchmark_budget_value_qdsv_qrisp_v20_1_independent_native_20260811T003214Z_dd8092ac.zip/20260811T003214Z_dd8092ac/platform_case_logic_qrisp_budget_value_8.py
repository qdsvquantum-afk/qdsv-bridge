def qrisp_case_budget_value(fields, decision, checkpoint):
    with fields["cost"] <= fields["budget"]:
        checkpoint(
            "native_nested_condition_environment",
            current_native_event="outer_condition_entered",
        )
        with fields["benefit"] >= fields["min_benefit"]:
            checkpoint(
                "native_nested_condition_environment",
                current_native_event="inner_condition_entered",
            )
            decision.flip()
