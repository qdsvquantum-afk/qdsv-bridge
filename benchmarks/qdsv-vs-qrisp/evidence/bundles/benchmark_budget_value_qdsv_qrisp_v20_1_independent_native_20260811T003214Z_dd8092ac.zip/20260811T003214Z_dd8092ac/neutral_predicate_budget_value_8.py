PUBLIC_PREDICATE = {'op': 'and',
 'args': [{'op': 'lte',
           'left': {'op': 'field', 'name': 'cost'},
           'right': {'op': 'field', 'name': 'budget'}},
          {'op': 'gte',
           'left': {'op': 'field', 'name': 'benefit'},
           'right': {'op': 'field', 'name': 'min_benefit'}}]}
