# Informe caso comun QDSV vs Qrisp v14

- Run ID: `20260810T171236Z_ba270205`
- Perfil principal: `budget_value_qdsv_qrisp_v14`
- Politica de versiones: `frozen_v14_single_budget_value_bilateral`
- Perfil onboarding: `readme_quickstart`
- Python: `3.12.13`

## Alcance

La comparación termina en el artefacto lógico ideal, QASM/Qiskit, evidencia y replay independiente.
Construcción, replay y normalización tienen timeout y memoria separados.
Esta corrida congela Bridge 0.6.1 y separa artefactos canonicos, optimizados nativos y normalizacion externa.
El peak RSS es un guardrail absoluto del arbol de procesos e incluye paginas heredadas; no se usa para comparar plataformas.

## Preflight operacional

Los canarios solo controlan viabilidad operativa; no usan labels, respuestas esperadas ni resultados semanticos.

``{"QDSV": {"canonical": {"version": "qdsv_canonical_service_preflight.v2", "ok": true, "blocking": false, "status": "passed", "catalog_consulted": true, "canonical_capability_signal": null, "errors": []}, "optimization_optional": {"version": "qdsv_optional_optimization_preflight.v1", "ok": true, "status": "passed", "required_profile": "qiskit_structural_exact_v1", "required_acceptance_policy": "pareto_no_regression_v1", "errors": []}}, "Qrisp": {"version": "qrisp_adapter_qualification_reference.v1", "status": "not_required", "strategy": "explicit_control_anf", "qualification": ["D1", "D2", "D3"], "battery_policy": "execute_each_case_independently"}}``

## Controles de entorno

Qrisp: ``{"version": "qrisp_packaging_compatibility.v1", "distribution": "qrisp", "distribution_version": "0.9.6", "canonical_module": "qrisp.permeability.unqomp", "packaged_module": "qrisp.permeability.qc_transformations.unqomp", "alias_applied": true, "module_path": "/usr/local/lib/python3.12/dist-packages/qrisp/permeability/qc_transformations/unqomp.py", "module_sha256": "575a05c250caec4d13b939558c941a8b27026f9bd357d0411f7f30f23f74fa08", "framework_source_modified": false, "semantic_adapter_modified": false}``

Estrategia Qrisp: `explicit_control_anf`; preparación exacta del dominio; workspace 0; uncomputation automática desactivada.

Procedencia de calificación Qrisp: ``{"strategy": "explicit_control_anf", "source_run_id": "20260806T221324Z_d2c7c1c0", "source_zip_sha256": "0311e14eb60bdf95760159925d660b9e9eb79e3cc43637830740244505b39815", "diagnostic_cases": ["D1", "D2", "D3"], "qualification_result": "passed", "benchmark_dependency": false, "note": "La batería vuelve a validar cada caso; esta referencia solo documenta el origen del adaptador."}``

## Smoke test del README de Bridge

| access_profile    | excluded_from_cross_platform_benchmark   | status   |
|:------------------|:-----------------------------------------|:---------|
| readme_quickstart | True                                     | not_run  |

El smoke test se excluye de cobertura y recursos cruzados.

## Vistas logicas nativas de QDSV

| run_id                    | platform   | case_id        | artifact_role              | recommended   | delivery_mode   | artifact_status   | artifact_digest                                                         | semantic_equivalence   | artifact_format   |   artifact_bytes | artifact_sha256                                                  | status             | stage   | detected_format   |   replay_seconds |   native_qubits |   native_depth |   native_size | native_ops                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | replay_status     | semantic_status    | sampled_consistency   | verification_strength   |   shots |   observed_mismatch_rate |   observed_invalid_rate |   observed_dirty_rate |   mismatch_probability |   invalid_probability |   dirty_ancilla_probability |   mismatch_zero_event_upper_95_pointwise |   invalid_zero_event_upper_95_pointwise |   dirty_zero_event_upper_95_pointwise |   mismatch_zero_event_upper_95_familywise |   invalid_zero_event_upper_95_familywise |   dirty_zero_event_upper_95_familywise | candidate_distribution_status   |   candidate_distribution_alpha |   candidate_distribution_tolerance |   candidate_marginal_max_error | candidate_bits   | predicate_bits   | mapping_source    | mapping_sources                                                                                                                                                                                                                                                                                                                        | observed_distribution                                                                                                                                                                                            |   peak_rss_mb |
|:--------------------------|:-----------|:---------------|:---------------------------|:--------------|:----------------|:------------------|:------------------------------------------------------------------------|:-----------------------|:------------------|-----------------:|:-----------------------------------------------------------------|:-------------------|:--------|:------------------|-----------------:|----------------:|---------------:|--------------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------------------|:-------------------|:----------------------|:------------------------|--------:|-------------------------:|------------------------:|----------------------:|-----------------------:|----------------------:|----------------------------:|-----------------------------------------:|----------------------------------------:|--------------------------------------:|------------------------------------------:|-----------------------------------------:|---------------------------------------:|:--------------------------------|-------------------------------:|-----------------------------------:|-------------------------------:|:-----------------|:-----------------|:------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------:|
| 20260810T171236Z_ba270205 | QDSV       | budget_value_8 | canonical_ideal_artifact   | False         | inline          |                   | sha256:0422f66957b15dc39927392de1a3b7dd1f50189e7d35dec2d7133ef169ea7668 |                        | qasm2             |            48076 | 57dede1c47965f43e1002cde4b5ad22f662327c87f2bb68be9b336a009089e62 | sampled_consistent | replay  | qasm2             |          1.09159 |              11 |            542 |           794 | {'x': 556, 'mcx': 192, 'measure': 4, 'h': 3, 'ccx': 2, 'mcx_125080237361056': 1, 'mcx_125080237366480': 1, 'mcx_125080237367872': 1, 'mcx_125080237369408': 1, 'mcx_125080237371088': 1, 'mcx_125080237371376': 1, 'mcx_125080237371424': 1, 'mcx_125080237371520': 1, 'mcx_125080237370752': 1, 'mcx_125080237371328': 1, 'mcx_125080237368928': 1, 'mcx_125080237369120': 1, 'mcx_125080237368832': 1, 'mcx_125080237368784': 1, 'mcx_125080237374592': 1, 'mcx_125080237372480': 1, 'mcx_125080237375168': 1, 'mcx_125080237375360': 1, 'cx': 1, 'mcx_125080236916368': 1, 'mcx_125080236914592': 1, 'mcx_125080236916416': 1, 'mcx_125080236905760': 1, 'mcx_125080236914256': 1, 'mcx_125080236916320': 1, 'mcx_125080236915936': 1, 'mcx_125080236914112': 1, 'mcx_125080236913680': 1, 'mcx_125080240804384': 1, 'mcx_125080240804432': 1, 'mcx_125080240804240': 1, 'mcx_125080240804528': 1, 'mcx_125080240804576': 1, 'mcx_125080240802032': 1, 'mcx_125080240802560': 1, 'mcx_125080240802944': 1, 'mcx_125080240803328': 1} | completed_sampled | sampled_consistent | True                  | sampled_mps             |    8192 |                        0 |                       0 |                     0 |                      0 |                     0 |                           0 |                              0.000365623 |                             0.000365623 |                           0.000365623 |                               0.000499673 |                              0.000499673 |                            0.000499673 | statistically_consistent        |                           0.01 |                          0.0212203 |                     0.00756836 | [0, 1, 2]        | [10]             | artifact_contract | ['measurement_contract:root.materialization_evidence.circuit_realization_package.contracts.measurement', 'measurement_contract:root.circuit_realization_package.contracts.measurement', 'measurement_contract:root.semantic_preservation_report.canonical_materialization_evidence.circuit_realization_package.contracts.measurement'] | {'(0, 0)': 0.1212158203125, '(1, 1)': 0.12744140625, '(2, 0)': 0.122314453125, '(3, 0)': 0.118896484375, '(4, 0)': 0.13037109375, '(5, 0)': 0.132568359375, '(6, 0)': 0.1248779296875, '(7, 0)': 0.122314453125} |       356.383 |
| 20260810T171236Z_ba270205 | QDSV       | budget_value_8 | optimized_logical_artifact | True          | inline          | accepted          | sha256:5acdc3b0d34d038861a7415f6a5eef29911d31a00cc1ed1b58ca078d31cf52a0 |                        | qasm2             |            43084 | 133d9735980281958bbcfb9c2199714a229217731c9e5b42ec50957fb9f995c3 | sampled_consistent | replay  | qasm2             |          1.07311 |              11 |            368 |           494 | {'x': 256, 'mcx': 192, 'measure': 4, 'h': 3, 'ccx': 2, 'mcx_125080237361056': 1, 'mcx_125080237366480': 1, 'mcx_125080237367872': 1, 'mcx_125080237369408': 1, 'mcx_125080237371088': 1, 'mcx_125080237371376': 1, 'mcx_125080237371424': 1, 'mcx_125080237371520': 1, 'mcx_125080237370752': 1, 'mcx_125080237371328': 1, 'mcx_125080237368928': 1, 'mcx_125080237369120': 1, 'mcx_125080237368832': 1, 'mcx_125080237368784': 1, 'mcx_125080237374592': 1, 'mcx_125080237372480': 1, 'mcx_125080237375168': 1, 'mcx_125080237375360': 1, 'mcx_125080236916368': 1, 'mcx_125080236914592': 1, 'mcx_125080236916416': 1, 'mcx_125080236905760': 1, 'mcx_125080236914256': 1, 'mcx_125080236916320': 1, 'mcx_125080236915936': 1, 'mcx_125080236914112': 1, 'mcx_125080236913680': 1, 'cx': 1, 'mcx_125080240804384': 1, 'mcx_125080240804432': 1, 'mcx_125080240804240': 1, 'mcx_125080240804528': 1, 'mcx_125080240804576': 1, 'mcx_125080240802032': 1, 'mcx_125080240802560': 1, 'mcx_125080240802944': 1, 'mcx_125080240803328': 1} | completed_sampled | sampled_consistent | True                  | sampled_mps             |    8192 |                        0 |                       0 |                     0 |                      0 |                     0 |                           0 |                              0.000365623 |                             0.000365623 |                           0.000365623 |                               0.000499673 |                              0.000499673 |                            0.000499673 | statistically_consistent        |                           0.01 |                          0.0212203 |                     0.00756836 | [0, 1, 2]        | [10]             | artifact_contract | ['measurement_contract:root.materialization_evidence.circuit_realization_package.contracts.measurement', 'measurement_contract:root.circuit_realization_package.contracts.measurement', 'measurement_contract:root.semantic_preservation_report.canonical_materialization_evidence.circuit_realization_package.contracts.measurement'] | {'(0, 0)': 0.1212158203125, '(1, 1)': 0.12744140625, '(2, 0)': 0.122314453125, '(3, 0)': 0.118896484375, '(4, 0)': 0.13037109375, '(5, 0)': 0.132568359375, '(6, 0)': 0.1248779296875, '(7, 0)': 0.122314453125} |       357.781 |

## Auditoria de optimizacion QDSV

| case_id        | logical_optimization_status   | optimization_contract_status   | optimization_contract_errors   | optimizer_qiskit_version   | canonical_semantic_status   | optimized_semantic_status   | recommended_semantic_status   | native_artifact_role     | recommended_delivery_mode   |
|:---------------|:------------------------------|:-------------------------------|:-------------------------------|:---------------------------|:----------------------------|:----------------------------|:------------------------------|:-------------------------|:----------------------------|
| budget_value_8 | accepted                      | passed                         | []                             | 2.3.0                      | sampled_consistent          | sampled_consistent          | sampled_consistent            | canonical_ideal_artifact | inline                      |

## Cobertura por estado

| platform   |   sampled_consistent |
|:-----------|---------------------:|
| QDSV       |                    1 |
| Qrisp      |                    1 |

## Interpretación de cobertura

| platform   |   total_cases |   passed |   platform_outcomes_observed |   adapter_gaps |   operational_incomplete |   semantic_failures |
|:-----------|--------------:|---------:|-----------------------------:|---------------:|-------------------------:|--------------------:|
| QDSV       |             1 |        1 |                            1 |              0 |                        0 |                   0 |
| Qrisp      |             1 |        1 |                            1 |              0 |                        0 |                   0 |

## Matriz por caso

| case_id        | QDSV               | Qrisp              |
|:---------------|:-------------------|:-------------------|
| budget_value_8 | sampled_consistent | sampled_consistent |

## Fuerza de validación semántica

| case_id        | QDSV        | Qrisp       |
|:---------------|:------------|:------------|
| budget_value_8 | sampled_mps | sampled_mps |

## Comparación directa del caso común

| platform   | case_id        | input_artifact_role      | validation         | common_case_eligible   | verification_strength   |   shots |   native_qubits |   native_depth |   native_gates | normalized_status   |   normalized_qubits |   normalized_depth |   normalized_cx |   construction_seconds | operational_status   | resource_comparison_eligible   |
|:-----------|:---------------|:-------------------------|:-------------------|:-----------------------|:------------------------|--------:|----------------:|---------------:|---------------:|:--------------------|--------------------:|-------------------:|----------------:|-----------------------:|:---------------------|:-------------------------------|
| QDSV       | budget_value_8 | canonical_ideal_artifact | sampled_consistent | True                   | sampled_mps             |    8192 |              11 |            542 |            794 | normalized          |                  11 |               7518 |            3997 |                7.14493 | sampled_consistent   | True                           |
| Qrisp      | budget_value_8 | platform_native_artifact | sampled_consistent | True                   | sampled_mps             |    8192 |              47 |           4825 |           9145 | normalized          |                  47 |              26821 |           16922 |               10.906   | sampled_consistent   | True                           |

Comparación cuantitativa de recursos habilitada: True

## Casos comparables

Al menos dos plataformas: ['budget_value_8']

Ambas plataformas: ['budget_value_8']

## Esfuerzo verificable

Harness común no atribuible: 40 LOC

| platform   |   reusable_adapter_loc |   environment_compatibility_loc |   measured_cases |   neutral_case_definition_loc_median |   end_user_invocation_loc_median |   benchmark_integration_loc_median |   additional_case_invocation_loc_median |
|:-----------|-----------------------:|--------------------------------:|-----------------:|-------------------------------------:|---------------------------------:|-----------------------------------:|----------------------------------------:|
| QDSV       |                    154 |                               0 |                1 |                                   16 |                                6 |                                160 |                                       6 |
| Qrisp      |                    257 |                              38 |                1 |                                   16 |                                1 |                                296 |                                       1 |

## Regla de interpretación

No se declara ganador global.
Los recursos solo se comparan si ambas plataformas son sampled_consistent y la normalización común termina.
Las brechas del adaptador, autenticación, soporte, recursos, memoria y corrección permanecen separadas.