circuit, qasm_source, qpy_b64, metadata = build_qrisp_case(BUSINESS_CASE)
