from qdsv_bridge import QDSVBridgeClient, select_recommended_artifact
spec = qdsv_spec_from_case(BUSINESS_CASE)
client = QDSVBridgeClient()
result = client.generate(spec)
artifact = select_recommended_artifact(result)
qasm_source = artifact['content']
