
SUPPORTED_PUBLIC_AST_OPS = {
    "field", "const", "add", "sub", "mul", "squared_diff",
    "eq", "ne", "lt", "lte", "gt", "gte", "and", "or", "not",
}

def validate_public_ast(node, data_columns):
    if not isinstance(node, dict) or "op" not in node:
        raise AdapterError("Nodo AST inválido.")
    op = node["op"]
    if op not in SUPPORTED_PUBLIC_AST_OPS:
        raise AdapterNotImplemented(f"Operación pública no implementada por el adaptador: {op}")
    if op == "field":
        name = node.get("name")
        if name not in data_columns:
            raise AdapterError(f"Campo no disponible en el caso: {name}")
        return
    if op == "const":
        if not isinstance(node.get("value"), (int, float, bool)):
            raise AdapterError(f"Constante no numérica: {node.get('value')!r}")
        return
    for key in ("left", "right", "arg"):
        if key in node:
            validate_public_ast(node[key], data_columns)
    for child in node.get("args", []):
        validate_public_ast(child, data_columns)

def validate_public_case(case):
    required = {"title", "business_family", "candidate_count", "data", "predicate"}
    missing = required - set(case)
    if missing:
        raise AdapterError(f"Campos faltantes del caso: {sorted(missing)}")
    n = int(case["candidate_count"])
    if n <= 0:
        raise AdapterError("candidate_count debe ser positivo.")
    if not case["data"]:
        raise AdapterError("El caso no contiene métricas.")
    for name, values in case["data"].items():
        if len(values) != n:
            raise AdapterError(f"Longitud incorrecta para {name}: {len(values)} != {n}")
        if not all(isinstance(value, (int, float, bool)) for value in values):
            raise AdapterError(f"Valores no numéricos en {name}")
    validate_public_ast(case["predicate"], set(case["data"]))
