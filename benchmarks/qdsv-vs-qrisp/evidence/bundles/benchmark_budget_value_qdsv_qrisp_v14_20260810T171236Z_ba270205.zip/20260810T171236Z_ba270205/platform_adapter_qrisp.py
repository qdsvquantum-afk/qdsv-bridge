
def qrisp_bit_width_unsigned(values):
    maximum = max([0, *[int(value) for value in values]])
    return max(1, math.ceil(math.log2(maximum + 1)))

def qrisp_prepare_index_exact(index, candidate_count):
    from qrisp import h, prepare
    padded_size = 1 << len(index.reg)
    if candidate_count == padded_size:
        h(index)
        return
    probabilities = [
        1 / candidate_count if value < candidate_count else 0.0
        for value in range(padded_size)
    ]
    prepare(index, np.sqrt(probabilities), method="qiskit")

def qrisp_toggle_explicit_field(index, field, values):
    from qrisp import control, x
    for candidate, value in enumerate(values):
        integer = int(value)
        for bit in range(len(field.reg)):
            if (integer >> bit) & 1:
                with control(index.reg, ctrl_state=candidate):
                    x(field[bit])

def qrisp_build_explicit_fields(index, case):
    from qrisp import QuantumFloat
    fields = {}
    loaders = []
    for name, values in case["data"].items():
        field = QuantumFloat(
            qrisp_bit_width_unsigned(values),
            signed=False,
            qs=index.qs,
            name=f"{name}_value",
        )
        qrisp_toggle_explicit_field(index, field, values)
        fields[name] = field
        loaders.append((field, list(values)))
    return fields, loaders

def qrisp_expr(node, fields):
    op = node["op"]
    if op == "field":
        return fields[node["name"]]
    if op == "const":
        return node["value"]
    if op == "add":
        values = [qrisp_expr(child, fields) for child in node["args"]]
        result = values[0]
        for value in values[1:]:
            result = result + value
        return result
    if op == "sub":
        return qrisp_expr(node["left"], fields) - qrisp_expr(node["right"], fields)
    if op == "mul":
        return qrisp_expr(node["left"], fields) * qrisp_expr(node["right"], fields)
    if op == "squared_diff":
        delta = qrisp_expr(node["left"], fields) - qrisp_expr(node["right"], fields)
        return delta * delta
    if op in {"eq", "ne", "lt", "lte", "gt", "gte"}:
        left = qrisp_expr(node["left"], fields)
        right = qrisp_expr(node["right"], fields)
        return {
            "eq": lambda: left == right,
            "ne": lambda: left != right,
            "lt": lambda: left < right,
            "lte": lambda: left <= right,
            "gt": lambda: left > right,
            "gte": lambda: left >= right,
        }[op]()
    raise AdapterNotImplemented(
        f"El nodo {op!r} no es una expresión aritmética o comparación soportada."
    )

QRISP_BOOLEAN_COMPARISON_OPS = {"eq", "ne", "lt", "lte", "gt", "gte"}

def qrisp_canonical_node_key(node):
    return json.dumps(node, sort_keys=True, separators=(",", ":"))

def qrisp_xor_polynomials(left, right):
    result = set(left)
    for monomial in right:
        if monomial in result:
            result.remove(monomial)
        else:
            result.add(monomial)
    return result

def qrisp_multiply_polynomials(left, right):
    result = set()
    for left_term in left:
        for right_term in right:
            term = frozenset(set(left_term) | set(right_term))
            if term in result:
                result.remove(term)
            else:
                result.add(term)
    return result

def qrisp_boolean_anf(node, leaf_registry):
    op = node["op"]
    if op in QRISP_BOOLEAN_COMPARISON_OPS:
        key = qrisp_canonical_node_key(node)
        leaf_registry[key] = node
        return {frozenset({key})}
    if op == "and":
        result = {frozenset()}
        for child in node["args"]:
            result = qrisp_multiply_polynomials(
                result, qrisp_boolean_anf(child, leaf_registry)
            )
        return result
    if op == "or":
        result = set()
        for child in node["args"]:
            child_poly = qrisp_boolean_anf(child, leaf_registry)
            result = qrisp_xor_polynomials(
                qrisp_xor_polynomials(result, child_poly),
                qrisp_multiply_polynomials(result, child_poly),
            )
        return result
    if op == "xor":
        result = set()
        for child in node["args"]:
            result = qrisp_xor_polynomials(
                result, qrisp_boolean_anf(child, leaf_registry)
            )
        return result
    if op == "not":
        return qrisp_xor_polynomials(
            {frozenset()}, qrisp_boolean_anf(node["arg"], leaf_registry)
        )
    raise AdapterNotImplemented(
        f"La estrategia ANF esperaba un nodo booleano y recibió {op!r}."
    )

def qrisp_build_leaf_condition(node, fields):
    from qrisp import auto_uncompute
    @auto_uncompute
    def build():
        return qrisp_expr(node, fields)
    return build()

def qrisp_apply_boolean_anf(node, fields, target):
    from contextlib import ExitStack
    from qrisp import x

    leaf_registry = {}
    polynomial = qrisp_boolean_anf(node, leaf_registry)
    ordered_terms = sorted(
        polynomial, key=lambda term: (len(term), tuple(sorted(term)))
    )
    for monomial in ordered_terms:
        if not monomial:
            x(target[0])
            continue
        with ExitStack() as stack:
            for leaf_key in sorted(monomial):
                stack.enter_context(
                    qrisp_build_leaf_condition(leaf_registry[leaf_key], fields)
                )
            x(target[0])
    return {
        "anf_term_count": len(ordered_terms),
        "anf_max_degree": max([len(term) for term in ordered_terms], default=0),
        "anf_terms": [sorted(term) for term in ordered_terms],
    }

def qrisp_clean_explicit_fields(index, loaders):
    for field, values in reversed(loaders):
        qrisp_toggle_explicit_field(index, field, values)
        field.delete(verify=False)

def qrisp_normalize_qubit_identifier(value):
    text = str(value).strip()
    for old, new in [(".", "_"), ("[", "_"), ("]", ""), (" ", "")]:
        text = text.replace(old, new)
    return text

def qrisp_qiskit_register_index_map(circuit):
    aliases = {}
    for qreg in circuit.qregs:
        for offset, bit in enumerate(qreg):
            index = circuit.find_bit(bit).index
            for name in {qreg.name, f"{qreg.name}_{offset}", f"{qreg.name}.{offset}"}:
                aliases.setdefault(qrisp_normalize_qubit_identifier(name), []).append(index)
    return aliases

def qrisp_locate_qubit_indices(compiled, qiskit_circuit, qubits):
    aliases = qrisp_qiskit_register_index_map(qiskit_circuit)
    indices = []
    sources = []
    for qubit in qubits:
        if qubit in compiled.qubits:
            indices.append(compiled.qubits.index(qubit))
            sources.append("compiled_qubit_identity")
            continue
        normalized = qrisp_normalize_qubit_identifier(qubit)
        matches = sorted(set(aliases.get(normalized, [])))
        if len(matches) != 1:
            raise AdapterError(
                f"No se pudo localizar inequívocamente {qubit!s}; matches={matches}"
            )
        indices.append(matches[0])
        sources.append("qiskit_register_fallback")
    source = sources[0] if len(set(sources)) == 1 else "mixed"
    return indices, source

def build_qrisp_case(case):
    validate_public_case(case)
    compatibility_record = activate_qrisp_packaging_compatibility()

    import base64 as _base64
    import io as _io
    from qrisp import QuantumBool, QuantumFloat
    from qiskit import qpy as _qpy

    index = QuantumFloat(
        max(1, math.ceil(math.log2(case["candidate_count"]))),
        signed=False,
        name="candidate",
    )
    qrisp_prepare_index_exact(index, case["candidate_count"])
    fields, loaders = qrisp_build_explicit_fields(index, case)
    decision = QuantumBool(qs=index.qs, name="decision")
    anf_metadata = qrisp_apply_boolean_anf(case["predicate"], fields, decision)
    qrisp_clean_explicit_fields(index, loaders)

    intended = list(index.reg) + list(decision.reg)
    compiled = decision.qs.compile(
        workspace=0,
        intended_measurements=intended,
        disable_uncomputation=True,
        compile_mcm=False,
    )
    circuit = compiled.to_qiskit()
    candidate_bits, candidate_mapping_source = qrisp_locate_qubit_indices(
        compiled, circuit, list(index.reg)
    )
    predicate_bits, predicate_mapping_source = qrisp_locate_qubit_indices(
        compiled, circuit, list(decision.reg)
    )
    mapping_hint = {
        "candidate_bits": candidate_bits,
        "predicate_bits": predicate_bits,
        "source": (
            candidate_mapping_source
            if candidate_mapping_source == predicate_mapping_source
            else "mixed"
        ),
    }

    qpy_buffer = _io.BytesIO()
    _qpy.dump(circuit, qpy_buffer)
    qpy_b64 = _base64.b64encode(qpy_buffer.getvalue()).decode("ascii")

    qasm_source = None
    qasm_export_status = "not_attempted"
    qasm_export_error = None
    try:
        qasm_source = qasm2.dumps(circuit)
        qasm_export_status = "exported"
    except Exception as exc:
        qasm_export_status = "optional_export_failed"
        qasm_export_error = f"{type(exc).__name__}: {exc}"

    return circuit, qasm_source, qpy_b64, {
        "qasm_export_status": qasm_export_status,
        "qasm_export_error": qasm_export_error,
        "mapping_hint": mapping_hint,
        "compatibility_record": compatibility_record,
        "strategy": "explicit_control_anf",
        "candidate_preparation": "exact_valid_domain",
        "workspace": 0,
        "disable_uncomputation": True,
        "intended_measurements": True,
        "anf": anf_metadata,
        "observable_output": "decision",
    }
