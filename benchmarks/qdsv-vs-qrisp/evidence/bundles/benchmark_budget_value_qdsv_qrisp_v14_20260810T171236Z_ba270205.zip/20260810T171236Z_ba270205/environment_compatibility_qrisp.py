
def activate_qrisp_packaging_compatibility():
    import hashlib as _hashlib
    import importlib as _importlib
    import importlib.metadata as _metadata
    import pathlib as _pathlib
    import sys as _sys

    expected_version = "0.9.6"
    observed_version = _metadata.version("qrisp")
    if observed_version != expected_version:
        raise AdapterError(
            f"Compatibilidad Qrisp limitada a {expected_version}; instalada: {observed_version}"
        )

    canonical_name = "qrisp.permeability.unqomp"
    packaged_name = "qrisp.permeability.qc_transformations.unqomp"
    applied = False
    try:
        module = _importlib.import_module(canonical_name)
        source_module = canonical_name
    except ModuleNotFoundError as exc:
        if exc.name != canonical_name:
            raise
        module = _importlib.import_module(packaged_name)
        _sys.modules[canonical_name] = module
        source_module = packaged_name
        applied = True

    module_path = _pathlib.Path(module.__file__).resolve()
    return {
        "version": "qrisp_packaging_compatibility.v1",
        "distribution": "qrisp",
        "distribution_version": observed_version,
        "canonical_module": canonical_name,
        "packaged_module": source_module,
        "alias_applied": applied,
        "module_path": str(module_path),
        "module_sha256": _hashlib.sha256(module_path.read_bytes()).hexdigest(),
        "framework_source_modified": False,
        "semantic_adapter_modified": False,
    }
